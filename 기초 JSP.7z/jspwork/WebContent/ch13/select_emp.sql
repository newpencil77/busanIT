select * from member;

delete from member;
commit;