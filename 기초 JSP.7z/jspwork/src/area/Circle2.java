package area;

public class Circle2
{
    private int radius;
    private double result;
    
    
    public int getRadius()
    {
        return radius;
    }
    
    public void setRadius(int radius)
    {
        this.radius = radius;
    }
    
    public double getResult()
    {
        return result;
    }
    
    public void setResult(double result)
    {
        this.result = result;
    }
       
    
    public String process() //�Ҽ��� ��°�ڸ����� ǥ��
    {
        this.result =  Math.PI* Math.pow(radius, 2);

        return  String.format("%.2f", result);

    }
    
    public double process2() //����
    {
        this.result =  Math.PI* Math.pow(radius, 2);
        
        return  Math.floor(result);
    }
    
    
}
