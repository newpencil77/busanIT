package area;

import java.util.HashMap;
import java.util.Map;

public class Test
{
    
    public static void main(String[] args)
    {
        Map<String, String> map = new HashMap<String, String>();
        
        map.put("�ȳ�", "�������");
        
        System.out.println(map.get("��"));
        System.out.println(map.get("�ȳ�"));
    }
    
}
