package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import area.Rectangle;


@WebServlet("/ch12Q/rec")
public class TestCon extends HttpServlet {
	private static final long serialVersionUID = 1L;

	

	public TestCon()
    {
        super();
        System.out.println("����");

    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	    request.setCharacterEncoding("euc-kr");
	    
	    int width= Integer.parseInt(request.getParameter("width"));
	    int height= Integer.parseInt(request.getParameter("height"));
	    
	    Rectangle rec = new Rectangle();
	    rec.setWidth(width);
	    rec.setHeight(height); 
	    
//	    ������Ʈ ��ü�� �����. setAttribute
	    request.setAttribute("rec", rec);
	    
//	    ������
	    RequestDispatcher rd = request.getRequestDispatcher("/ch12Q/rectangleForm.jsp");
	    rd.forward(request, response);
	 
	    
	    
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	    request.setCharacterEncoding("euc-kr");
	    
		doGet(request, response);
	}

}
