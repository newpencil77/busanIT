package com.controller.action;

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Action;

import magic.MemberBean;
import magic.MemberDAO;
import magic.OMemberDAO;
import magic.TableColumnsBean;
import myUtil.HanConv;
import myUtil.HanConv2;

public class AddMemberMySqlAction implements Action
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
//           String name="";
//        if(request.getParameter("name")!=null)
//        {
//            name= request.getParameter("name");
//            URLEncoder.encode(name,"euc-kr");
//        }
        
        
        String p1=request.getParameter("phone1");
        String p2=request.getParameter("phone2");
        String p3=request.getParameter("phone3");
        

        MemberBean mem = new MemberBean();
        mem.setId(request.getParameter("id"));
        mem.setPw(request.getParameter("pw"));
        mem.setName(request.getParameter("name"));

        mem.setTel(p1+"-"+p2+"-"+p3);
        mem.setmClass(Integer.parseInt(request.getParameter("mClass")));
        
        
        MemberDAO dao = MemberDAO.getInstance();
        
            dao.addMember(mem); 
            request.setAttribute("member", mem);
            
            return "/ch13/addMemberMySql.jsp";
    }
    
}
