package com.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Action;

import magic.MemberBean;
import magic.OMemberDAO;

public class DetailViewAction implements Action
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        
      OMemberDAO dao = OMemberDAO.getInstance();
        
       MemberBean mem = dao.detailView(request.getParameter("id"));
       
       request.setAttribute("member", mem);
       
        
        return "/ch14/updateMember2.jsp";
    }
    
}
