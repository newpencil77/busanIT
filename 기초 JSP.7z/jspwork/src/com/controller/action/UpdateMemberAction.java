package com.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Action;

import magic.MemberBean;
import magic.OMemberDAO;

public class UpdateMemberAction implements Action
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
         
        MemberBean mem = new MemberBean();
        mem.setId(request.getParameter("id"));
        mem.setName(request.getParameter("name"));
        mem.setmClass(Integer.parseInt(request.getParameter("mclass")));
        mem.setTel(request.getParameter("tel"));
        
        OMemberDAO dao = OMemberDAO.getInstance();
        dao.updateMember(mem);
        
        return "redirect:/ch14/viewMember.jsp";
    }
    
}
