package com.controller.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Action;

import magic.MemberBean;
import magic.MemberDAO;
import magic.OMemberDAO;
import magic.TableColumnsBean;

public class ViewMemberMySqlAction implements Action
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
                
        MemberDAO dao = MemberDAO.getInstance();
        
            try
            {
                 ArrayList<MemberBean> arr= new  ArrayList<>();
                 arr= dao.viewMembers();
                 
                 request.setAttribute("arr", arr);
                
                 
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
            
            return "/ch13/viewMemberMySql.jsp";
    }
    
}
