package com.controller.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.Action;

import magic.OMemberDAO;
import magic.TableColumnsBean;

public class ViewTableSchemaAction implements Action
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        
        String tableName= request.getParameter("tableName").toUpperCase();
        
        OMemberDAO dao = OMemberDAO.getInstance();
        
            try
            {
                 ArrayList<TableColumnsBean> arr= new  ArrayList<>();
                 arr= dao.viewColumns(tableName);       
                 
                 request.setAttribute("arr", arr);
                
                 
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
            
            return "/ch13/userTabColumnsForm.jsp";
    }
    
}
