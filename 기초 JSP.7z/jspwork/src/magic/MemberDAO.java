package magic;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class MemberDAO
{
    private static MemberDAO instance= new MemberDAO();
    
    public static MemberDAO getInstance()
    {
        return instance;
    }
    

    private MemberDAO(){}
    
    

   private Connection getConnection() 
   {
       String url = "jdbc:mysql://localhost:3306/jspdb";
       String user = "root";
       String passwd = "0000";
       
       Connection con =null;
       
          try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(url, user, passwd);

        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
          
          return con;
          
   }
    
    
    public ArrayList<MemberBean> viewMembers() throws SQLException
    {
        Connection con= null;
        Statement st = null;
        ResultSet rs = null;
//        �������� arr �� ���������
        ArrayList<MemberBean> arr= new ArrayList<MemberBean>();
       
        
       con = getConnection();
       String sql= "SELECT * FROM member";
       
       
       
       try
        {              
            st= (Statement) con.createStatement();
            rs= st.executeQuery(sql);
            
            while(rs.next())
            {
                MemberBean member = new MemberBean();
                
                member.setId(rs.getString("id"));
                member.setName(rs.getString("name"));
                member.setmClass(rs.getInt("mclass"));
                member.setTel(rs.getString("tel"));
                
                arr.add(member);       
            }
                    
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(con!=null)
            {
                con.close();
            }
        }
           
       return arr;
       
    }
    
    
    public void addMember(MemberBean mem)
    {
        Connection con =null;
        PreparedStatement ps =null;
        
        
        String sql="INSERT INTO member VALUES(?,?,?,?,?)";
        
        try
        {
            con= getConnection();
            ps = con.prepareStatement(sql);    
            
            ps.setString(1, mem.getId());
            ps.setString(2, mem.getPw());
            ps.setString(3, mem.getName());
            ps.setInt(4, mem.getmClass());
            ps.setString(5, mem.getTel());
            
            ps.executeUpdate();
            
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        
    }
    
    
    
    
}
