package magic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class OMemberDAO
{
    private static OMemberDAO instance= new OMemberDAO();
    
    public static OMemberDAO getInstance()
    {
        return instance;
    }
    

    private OMemberDAO(){}
    
    

   private Connection getConnection() 
   {
       String url = "jdbc:oracle:thin:@localhost:1521:xe";
       String user = "scott";
       String passwd = "0000";
       
        Connection con =null;
       
          try
        {
//            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection(url, user, passwd);

        }
//        catch (ClassNotFoundException e)
//        {
//            e.printStackTrace();
//        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
          
          return con;
          
   }
    

    
    
    
    
    public ArrayList<TableColumnsBean> viewColumns(String tableName) throws SQLException
    {
        Connection con= null;
        Statement st = null;
        ResultSet rs = null;
        
        ArrayList<TableColumnsBean> arr= new ArrayList<TableColumnsBean>();
       
       con = getConnection();
       
//       �������� ���� StringBuffer ����غ���. �׷���. �� ���ڿ��� ���ϱ� ���ؼ��� �ƴ϶�, �������� ���ؼ��� �� �� �ְڱ���
       
       StringBuffer sql= new StringBuffer(300);
       sql.append("select cname AS �̸�, ");
       sql.append("coltype AS ��������, ");
       sql.append("width AS �హ��, ");
       sql.append("nulls AS �ο��� ");
       sql.append("from col where tname = '"+tableName+"'");
       
//       String sql="select cname AS �̸�, coltype AS ��������, width AS �హ��, nulls AS �ο��� from col where tname = '"+tableName+"'";

       try
        {              
            st= con.createStatement();
            rs= st.executeQuery(sql.toString());
            
            while(rs.next())
            {
                 TableColumnsBean cols = new TableColumnsBean();
                 
                 cols.setColName(rs.getString(1));
                 cols.setColFormat(rs.getString(2));
                 cols.setColLength(rs.getString(3));
                 cols.setCheckNull(rs.getString(4));
                                  
                 arr.add(cols);
                 
            }
                    
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(rs!=null)
            {
                rs.close();
            }
            if(st!=null)
            {
                st.close();
            }
            if(con!=null)
            {
                con.close();
            }
        }
           
       return arr;
       
    }
    
    
    
    public ArrayList<MemberBean> viewMembers() throws SQLException
    {
        Connection con= null;
        Statement st = null;
        ResultSet rs = null;

        ArrayList<MemberBean> arr= new ArrayList<MemberBean>();
       
        
       con = getConnection();
       String sql= "SELECT * FROM member2";
       
       
       
       try
        {              
            st= (Statement) con.createStatement();
            rs= st.executeQuery(sql);
            
            while(rs.next())
            {
                MemberBean member = new MemberBean();
                
                member.setId(rs.getString("id"));
                member.setName(rs.getString("name"));
                member.setmClass(rs.getInt("mclass"));
                member.setTel(rs.getString("tel"));
                
                arr.add(member);       
            }
                    
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            if(con!=null)
            {
               con.close();
            }
        }
           
       return arr;     
    }
    
    
    public MemberBean detailView(String id)
    {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        MemberBean mem = null;
        
        con = getConnection();
        String sql = "SELECT name, mclass, tel from member2 where id=?";
        
        try
        {
            ps= con.prepareStatement(sql);
            ps.setString(1, id);
            
            rs= ps.executeQuery();
            
            if(rs.next())
            {
                mem= new MemberBean();
                mem.setId(id);
                mem.setName(rs.getString(1));
                mem.setmClass(rs.getInt(2));
                mem.setTel(rs.getString(3));
            }
            
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        
        return mem;
    }
    
    
    public void updateMember(MemberBean m)
    {
        Connection con =null;
        PreparedStatement ps = null;
      
        con = getConnection();
        
        String sql= "UPDATE member2 SET name=?, mclass=?, tel=?, WHERE id=?";
        
        try
        {
            ps = con.prepareStatement(sql);
            
            ps.setString(1, m.getName());
            ps.setInt(2, m.getmClass());
            ps.setString(3, m.getTel());
            ps.setString(4, m.getId());
            
            ps.executeUpdate();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }


    }
    
    
}
