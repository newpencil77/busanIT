package magic;

public class TableColumnsBean
{
    private String colName;
    private String colFormat;
    private String colLength;
    private String checkNull;
    
    
    public String getColName()
    {
        return colName;
    }
    public void setColName(String colName)
    {
        this.colName = colName;
    }
    public String getColFormat()
    {
        return colFormat;
    }
    public void setColFormat(String colFormat)
    {
        this.colFormat = colFormat;
    }
    public String getColLength()
    {
        return colLength;
    }
    public void setColLength(String colLength)
    {
        this.colLength = colLength;
    }
    public String getCheckNull()
    {
        return checkNull;
    }
    public void setCheckNull(String checkNull)
    {
        this.checkNull = checkNull;
    }
    
    
    
}
