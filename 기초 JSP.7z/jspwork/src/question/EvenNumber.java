package question;

public class EvenNumber
{
    private int num;

    public int getNum()
    {
        return num;
    }

    public void setNum(int num)
    {
        this.num = num;
    }
    
    
    public String process()
    {
        int sum=0;
        
        for(int i=1; i<=num; i++)
        {
            if(i%2==0)
            {
                sum+= i;
            }
        }
        
        return "�Էµ� ���� " + num + "�� ¦������ �հ�� "+ sum;
        
    }
    
    
    public String process2()
    {
        int sum=0;
        
        for(int i=0; i<=num; i+=2)
        {
                sum+= i;
        }
        
        return "�Էµ� ���� " + num + "�� ¦������ �հ�� "+ sum;
        
    }
    
    
}
