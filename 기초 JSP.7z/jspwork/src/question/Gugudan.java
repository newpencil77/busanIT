package question;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Gugudan
{
    public int process(int num1, int num2)
    {
        return num1 * num2; 
    }
    
    
    public Map<String, Integer> process(int num1)
    {
        Map<String, Integer> gugu= new HashMap< >();
//        Map<String, Integer> gugu= new TreeMap< >();
        
        
//        for(int i =1; i<=9; i++)
//        {
//            gugu.put(num1+"*"+i+"=", num1*i);
//        }
//        
//        return gugu;
        
        
//        ���� ���ĵǴ� �� ����.
        for(int i =9; i>=1; i--)
        {
            gugu.put(num1+"*"+i+"=", num1*i);
        }
        
        return gugu;
        
        
                
    }
    
    
}
