package question;

public class Three
{
    private int inputNum;
    private int checkNum;

    public int getInputNum()
    {
        return inputNum;
    }

    public void setInputNum(int inputNum)
    {
        this.inputNum = inputNum;
    }

    public int getCheckNum()
    {
        return checkNum;
    }

    public void setCheckNum(int checkNum)
    {
        this.checkNum = checkNum;
    }

    
    
    public boolean process()
    {
        
        if(inputNum%checkNum==0)
        {
            return true;
        }
        
        return false;   
    }
    
    public String process2()
    {
        String result="";
                
        if(inputNum%checkNum==0)
        {
            return checkNum+"�� ����Դϴ�.";
        }
        
        return checkNum+"�� ����� �ƴմϴ�.";   
    }
    
    
    
}
