function postSubmitVali()
{

    let userName= document.frm.b_name;
    let email = document.frm.b_email;
    let title = document.frm.b_title;
    let content= document.frm.b_content;


    if(userName.value.length<4)
    {
        alert("아이디를 4자 이상 입력해주세요");
        userName.focus();
		return false;
    }

    else if(email.value=="" || title.value=="" || content.value=="")
    {
        alert("값을 모두 입력해주세요.");
		return false;
    }

}



