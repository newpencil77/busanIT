
if(window.XMLHttpRequest)
{
    var xmlObj= new XMLHttpRequest();


xmlObj.onreadystatechange= function(){

    if(xmlObj.readyState==4 && xmlObj.status==200)
    {
        let resultJson = eval(xmlObj.responseText)
        
        let str="";

//			for(a in resultJson)
//	여기서 a가 0, 1,2,3,4 이런 값이 나오고 있음
        
        for(var i = 0; i<resultJson.length; i++)
        {
            // document.querySelector("#listTable").append("<tr><td>"+a+"</td></tr>");
			str+= "<tr>";
            str+= "<td>"+ resultJson[i].b_id +"</td>";
            str+= "<td>"+resultJson[i].b_title+"</td>";
            str+= "<td><a href='#'>"+resultJson[i].b_name+"</a></td>";
			str+= "</tr>";
        }

         document.querySelector("#testtt").innerHTML= str;
    }
};

xmlObj.open("GET","list.b");
xmlObj.send();

}
else
{
    alert("XMLHttpRequest 객체 생성 실패");
}

