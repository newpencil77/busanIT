package magic.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDBBean
{
    
    //�̱������� ��ü �ϳ� ������  
    private static BoardDBBean instance;
    
    private BoardDBBean() {};
    
    public static BoardDBBean getinstance()
    {
        if(instance==null)
        {
            instance = new BoardDBBean();
        }
        
        return instance;
    }
    
//    getConnection
    
    private Connection getConnection() throws Exception
    {  
        Context ctx= new InitialContext();
        DataSource data= (DataSource)ctx.lookup("java:comp/env/jdbc/jsp");    
        return data.getConnection();       
    }
    
    
////    �Խ��ǿ� �� �߰�
//    public int insertBoard(BoardBean bb)
//    {
//        Connection con= null;
//        PreparedStatement ps = null;
//        
//        int result =0;
//        
//        String sql= "INSERT INTO mboard VALUES (?,?,?,?)";
//        
//        try
//        {
//            con = getConnection();
//            ps= con.prepareStatement(sql);
//            
//            ps.setString(1, bb.getB_name());
//            ps.setString(2, bb.getB_email());
//            ps.setString(3, bb.getB_title());
//            ps.setString(4, bb.getB_content());
//            
//            result = ps.executeUpdate();
//            
//        }
//        catch (Exception e)
//        {
//            e.printStackTrace();
//        }
//        finally
//        {
//          closeConnection(con, ps, null);  
//        }
//        
//        return result;
//    }
    
   
  
//  �Խ��ǿ� �� �߰�
  public int insertBoard(BoardBean bb)
  {
      Connection con= null;
      PreparedStatement ps = null;
      
      Statement st = null;
      ResultSet rs = null;
      
      int b_id=1;
      int result =0;
      
      String sql= "SELECT max(b_id) from mboard";

      try
      {
          con = getConnection();
          
          st= con.createStatement();
          rs= st.executeQuery(sql);
          
          if(rs.next())
          {
              b_id= rs.getInt(1)+1;
          }

          sql= "INSERT INTO mboard VALUES (?,?,?,?,?)";

          ps= con.prepareStatement(sql);
          
          ps.setInt(1, b_id);
          ps.setString(2, bb.getB_name());
          ps.setString(3, bb.getB_email());
          ps.setString(4, bb.getB_title());
          ps.setString(5, bb.getB_content());

          
          result = ps.executeUpdate();
          
      }
      catch (Exception e)
      {
          e.printStackTrace();
      }
      finally
      {
        closeConnection(con, ps, st, rs);  
      }
      
      return result;
  }
  
  
  public ArrayList<BoardBean> listBoard()
  {
      Connection con= null;
      Statement st = null;
      ResultSet rs= null;
      
      String sql="SELECT * FROM mboard";
      
      ArrayList<BoardBean> arr = new ArrayList<BoardBean>();
      
      try
    {
        con =getConnection();
        st= con.createStatement();
        rs= st.executeQuery(sql);
        
        while(rs.next())
        {
            BoardBean bb = new BoardBean();
            
            bb.setB_id(rs.getInt("b_id"));
            bb.setB_name(rs.getString("b_name"));
            bb.setB_email(rs.getString("b_email"));
            bb.setB_title(rs.getString("b_title"));
            bb.setB_content(rs.getString("b_content"));
            
            arr.add(bb);
           
        }
    }
    catch (Exception e)
    {
        e.printStackTrace();
    }
    finally
    {
        closeConnection(con, null, st, rs);
    }
      
      return arr;
      
      
  }
    
  
  public BoardBean getBoard(int b_id)
  {
      Connection con = null;
      Statement st = null;
      ResultSet rs = null;
      
      BoardBean bb= null;
         
      String sql= "select * from mboard where b_id="+b_id+"";
      try
    {
        con = getConnection();
        st= con.createStatement();
        rs= st.executeQuery(sql);
        
        if(rs.next())
        {
            bb= new BoardBean();
            bb.setB_id(rs.getInt("b_id"));
            bb.setB_name(rs.getString("b_name"));
            bb.setB_title(rs.getString("b_title"));
            bb.setB_content(rs.getString("b_content"));
            bb.setB_email(rs.getString("b_email"));
        }
        
    }
    catch (Exception e)
    {
        e.printStackTrace();
    }
      finally
      {
          closeConnection(con, null, st, rs);
      }
      
      return bb;
      
  }
    

    private void closeConnection(Connection con, PreparedStatement ps, Statement st, ResultSet rs)
    {
        try
        {
            if(rs!=null)
            {
                rs.close();
            }

            if(ps!=null)
            {
                ps.close();
            }
            
            if(st!=null)
            {
                st.close();
            }
            
            if(con!=null)
            {
                con.close();
            }
            
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
    
    
    
    
    

}
