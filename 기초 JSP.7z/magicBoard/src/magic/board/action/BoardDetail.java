package magic.board.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.board.BoardBean;
import magic.board.BoardDBBean;

public class BoardDetail implements Actions
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        int id= Integer.parseInt(request.getParameter("b_id"));
        
        BoardDBBean dao = BoardDBBean.getinstance();
        BoardBean bb = dao.getBoard(id);
        
        request.setAttribute("bb", bb);
        
        return "/show.jsp";
    }
    
}
