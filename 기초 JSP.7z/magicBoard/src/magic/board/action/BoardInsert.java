package magic.board.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.board.BoardBean;
import magic.board.BoardDBBean;

public class BoardInsert implements Actions
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        BoardBean bb = new BoardBean();
        
        bb.setB_name(request.getParameter("b_name"));
        bb.setB_email(request.getParameter("b_email"));
        bb.setB_title(request.getParameter("b_title"));
        bb.setB_content(request.getParameter("b_content"));
        
        BoardDBBean dao = BoardDBBean.getinstance();
        int result = dao.insertBoard(bb);
        
        request.setAttribute("result", result);
        
        return "/writeOkServlet.jsp";
    }
    
}
