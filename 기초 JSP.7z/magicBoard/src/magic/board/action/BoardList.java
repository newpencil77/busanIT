package magic.board.action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import magic.board.BoardBean;
import magic.board.BoardDBBean;

public class BoardList implements Actions
{
    
    @Override
    public String execute(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
        
        BoardDBBean dao = BoardDBBean.getinstance();
        ArrayList<BoardBean> arr = dao.listBoard();
        
        
//      request.setAttribute("arr", arr);     
//      return "/list.jsp";
        
        
        
        JSONArray jarr = new JSONArray();
        
        for(BoardBean bb: arr)
        {
           JSONObject obj = new JSONObject();
           obj.put("b_id", bb.getB_id());       
           obj.put("b_name", bb.getB_name());
           obj.put("b_email", bb.getB_email());
           obj.put("b_title", bb.getB_title());
           obj.put("b_content", bb.getB_content());
           
           jarr.add(obj);
        }
        
        request.setAttribute("jsonArr", jarr);
        
//        �� �ΰ��� �Ȱ��� ������� ����. 
        System.out.println(jarr);
        System.out.println(jarr.toString());
        
        return "callback";
    }
    
}
