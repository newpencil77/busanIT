package magic.board.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.board.action.Actions;
import magic.board.action.BoardDetail;
import magic.board.action.BoardInsert;
import magic.board.action.BoardList;

public class Factory
{
    
//    �׳� �ϳ��� �� �Ŵϱ� �̱���
    
    private static Factory instance;
    
    public static Factory getInstance()
    {
        if(instance==null)
        {
            instance= new Factory();    
        }
        
        return instance;
    }
    
    Map<String, Actions> map = new HashMap<>();
    

    private Factory()
    {
        //  insert
        map.put("/insert.b", new BoardInsert());
        
//        ����Ʈ����
        map.put("/list.b", new BoardList());
        
//        �����Ϻ�
        map.put("/detail.b", new BoardDetail());
        
    }
    
    
    public Actions getAction(String command)
    {
        Actions action = null;
        
        action = map.get(command);
        
        return action;
    }
    
    
    
    
}
