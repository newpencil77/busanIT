package magic.board.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.board.action.Actions;

@WebServlet("*.b")
public class FrontController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	    request.setCharacterEncoding("euc-kr");
	    response.setContentType("text/html; charset= euc-kr");
	    
//	    command �߷����� ���� �۾�
	    String command= getCommand(request, response);
	    System.out.println(command);
	    
	   
//	    ó������ �׼�
//	    ���丮�� ����. ���� ����.
 
	    Factory factory = Factory.getInstance();
	   Actions action= factory.getAction(command);
	   
	   if(action==null)
	   {
	       System.out.println("ó���� action ����");
	       return;
	   }
	   
	  String path= action.execute(request, response);
	  
	  if(path.equals("callback"))
	  {
//	      response.setContentType("application/json; charset= euc-kr");
	      
//	      ����Ʈ�� ���� �ʰ� �׳� �����͸� ������ �� ����?
	      PrintWriter out = response.getWriter();
	      out.print(request.getAttribute("jsonArr"));
	  }
	  else
	  {
	      RequestDispatcher rd = request.getRequestDispatcher(path);
	      rd.forward(request, response);	      
	  }
	  

	    
	    
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}
	
	
	private String getCommand(HttpServletRequest request, HttpServletResponse response)
	{
	    String uri = request.getRequestURI();
	    System.out.println(uri); //  /magicBoard/write.b
	    
	    
	    String contextPath = request.getContextPath();
	    System.out.println(contextPath); //  /magicBoard
	     
	    return uri.substring(contextPath.length()); 
	    
	}

}
