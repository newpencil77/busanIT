// 와 세상에ㅎㅎ 쿼리셀렉터 철자 주의. 무심코 er로 썼었음
// 아하. 그렇지. 바로 value값으로 초기화되어서, 다 빈 값이되는 가봄
// var id =document.querySelector("#id").value; 본보기로 살려둠
var userid =document.querySelector("#userid");
var pass= document.querySelector("#password");
var passConfirm= document.querySelector("#confirmPass");

// 아하. name이 예약어구나
//name.value가 자꾸 undefined가 됐었음
var InputName= document.querySelector("#name");
var email= document.querySelector("#email");

function checkValidation()
{

//let userid =document.querySelector("#userid");
//let pass= document.querySelector("#password");
//let passConfirm= document.querySelector("#confirmPass");
//let InputName= document.querySelector("#name");
//let email= document.querySelector("#email");

	if(userid.value=="")
	{
		alert("아이디를 써 주세요");
		return false;
	}
	
	if(userid.value.length<4)
	{
		alert("아이디를 4자 이상 써 주세요");
		return false;
	}
	
	if(pass.value=="")
	{
		alert("패스워드는 반드시 입력해야합니다.");
		return false;
	}
	
	if(pass.value!==passConfirm.value)
	{
		alert("패스워드가 일치하지 않습니다.");
		return false;
	}
	
	if(InputName.value=="")
	{
		alert("이름을 써주세요");
		return false;
	}
	
	if(email.value=="")
	{
		alert("이메일을 써주세요");
		return false;
	}
	
}



function updateCheckValidation()
{

	if(pass.value=="")
	{
		alert("패스워드는 반드시 입력해야합니다.");
		return false;
	}
	
	if(pass.value!==passConfirm.value)
	{
		alert("패스워드가 일치하지 않습니다.");
		return false;
	}
	
	if(email.value=="")
	{
		alert("이메일을 써주세요");
		return false;
	}
	
};




//버튼 클릭-> 데이터를 갖고 DB에 달려감. ID 중복 확인
//돌아와서 확인 결과 알려주기

//일단 데이터를 들고 가는 방법. 그리고 돌아와서 가져온 데이터를 쓰는 방법. 바닐라 자바스크립트에서


//1.일단 XMLHttpRequest를 쓸 수 있을 것임
//ㅎㅎ 합격

var checkIDBtn = document.querySelector("#checkIDBtn");
checkIDBtn.addEventListener('click', checkID);


function checkID()
{
    if(window.XMLHttpRequest)
    {
        var xmlObj= new XMLHttpRequest();
    }

	else
	{
		alert("XMLHttpRequest 객체 생성 실패");
		return;
	}

    let useridVal = document.querySelector("#userid").value;
    var reqPara= "userid="+useridVal;

	// onreadystatechange는 함수가 아니라고 함

//    xmlObj.onreadystatechange(this, function(){
   xmlObj.onreadystatechange= function(){

       if(xmlObj.readyState==4 && xmlObj.status==200)
       {
           let result= xmlObj.responseText;

		

           if(result==1)
           {
               alert("중복된 아이디입니다. 다른 아이디를 입력해주세요");
           }
           else
           {
               alert("사용 가능한 아이디입니다.");
           }
       }
//  });
};

    xmlObj.open("Post", "checkID.mem", true);
    xmlObj.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=euc-kr");

    xmlObj.send(reqPara);
    
}



//
//async function checkID()
//{
//	let userid = document.querySelector("#userid");
//	
//	let formData= new FormData();
//    formData.append("id", a);
//    
//    let response = await fetch
//        ("checkID.mem",
//            {
//                method: "POST",
//                headers: 
//                    {
//                        'Content-Type': 'application/x-www-form-urlencoded'
//                    },
//                body: formData
//            }
//        ).then(function(response)
//        {
//                let result= await response.text();
//
//                if(result==1)
//                {
//                    alert("사용 불가");
//                }
//                else
//                {
//                    alert("사용 가능한 아이디입니다.");
//                }
//        }).catch(function(error)
//        {
//            console.log(error);
//        });
//};


