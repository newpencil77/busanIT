/**
 * 
 */

function check_ok()
{
//	여기에서, reg_frm은 form 의 이름임. 
//	mem_uid는 input에서 아이디를 적는 창의 이름이고. 
	if(document.reg_frm.mem_uid.value.length==0)
	{
		alert("아이디를 입력해주세요");
		reg_frm.mem_uid.focus(); // 해당 인풋창에 포커스 주기.
		return;
	}
	
}