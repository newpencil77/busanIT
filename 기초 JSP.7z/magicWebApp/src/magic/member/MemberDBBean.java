package magic.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class MemberDBBean
{
    private static MemberDBBean instance;
    
    private MemberDBBean(){};
    
    public static MemberDBBean getInstance()
    {
        if(instance==null)
        {
            instance= new MemberDBBean();
        }
        return instance;
    }
    
    
    public Connection getConnection() throws Exception
    {
        Context ctx = new InitialContext();
        DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/jsp");
        return ds.getConnection();
    }
    
    
    public int insertMember(MemberBean member)
    {
        Connection con=null;
        PreparedStatement ps = null;
        int result=0;
        
        String sql="INSERT INTO membert(userid, password, name, email, address) VALUES (?,?,?,?,?)";
//        String sql="INSERT INTO membert VALUES (?,?,?,?,?,?)";
        
        try
        {
            con = getConnection();
            
            ps=con.prepareStatement(sql);
            ps.setString(1, member.getUserid());
            ps.setString(2, member.getPassword());
            ps.setString(3, member.getName());
            ps.setString(4, member.getEmail());
            ps.setString(5, member.getAddress());
//            ps.setTimestamp(5, member.getRegdate());
//            ps.setString(6, member.getAddress());
            
            result= ps.executeUpdate();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(con, null, ps, null);
        }
       
       return result;
    }
    
    
    public int confirmID(String id)
    {
        Connection con = null;
        Statement st = null;
        ResultSet rs= null;
        
        String sql="SELECT userid FROM membert WHERE userid='"+id+"'";
        
        try
        {
            con = getConnection();
           
            st= con.createStatement();
            rs= st.executeQuery(sql);
            
            if(rs.next())
            {
                return 1;
            }
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(con, st, null, rs);
        }
        
        return 0;
    }
    
    
    
    
//    ����� ����. �α���
    public int userLogin(String id, String pwd)
    {
        Connection con =null;
        Statement st = null;
        ResultSet rs =null;
        
        int result=-1; //���̵� ����
        
        String sql="SELECT password FROM membert WHERE userid='"+id+"'";
        
        try
        {
            con= getConnection();
            st= con.createStatement();
            rs= st.executeQuery(sql);
            
            if(rs.next())
            {
                if(rs.getString(1).equals(pwd))
                {
                    result=1;
                }
                else//��й�ȣ Ʋ�� ���. result 0
                {
                    result=0;
                } 
            }
              
//            if(rs.next() && rs.getString(1).equals(pwd)) //�α��� ����
//            {
//                 result=1;
//            }
////            �Ƥ��� �Ǽ��߳�. �̷��� �ϸ� ��й�ȣ�� Ʋ�� ��쿡�� ���� else�� ������
//            else //���̵� ����
//            {
//                result= -1;
//            }
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(con, st, null, rs);
        }
        
        return result;
    }
    
    
//    ���̵� ��ġ�ϸ� �ش� ����� ���� ��������
    public MemberBean getMember(String id)
    {
        Connection con =null;
        Statement st = null;
        ResultSet rs= null;
        
        MemberBean member= null;
        
        String sql="SELECT * FROM membert WHERE userid='"+id+"'";
        
        try
        {
            con = getConnection();
            st = con.createStatement();
            rs= st.executeQuery(sql);
            
            if(rs.next())
            {
                member = new MemberBean();
                member.setUserid(rs.getString("userid"));
                member.setName(rs.getString("name"));
                member.setPassword(rs.getString("password"));
                member.setEmail(rs.getString("email"));
                member.setRegdate(rs.getTimestamp("regdate"));
                member.setAddress(rs.getString("address"));
            }
            
            System.out.println(sql);
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
        return member;
               
    }
    
    
    public int updateMember(MemberBean m)
    {
        Connection con =null;
        PreparedStatement ps =null;
        
        int result= 0;
        
        String sql= "UPDATE membert SET password=?, email=?, address=? WHERE userid=?";
        
        try
        {
            con = getConnection();
            ps= con.prepareStatement(sql);
            
            ps.setString(1, m.getPassword());
            ps.setString(2, m.getEmail());
            ps.setString(3, m.getAddress());
            ps.setString(4, m.getUserid());
            
            result= ps.executeUpdate();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            closeConnection(con, null, ps, null);
        }
        
        return result;   
    }
    
    
    public void closeConnection(Connection con, Statement st, PreparedStatement ps, ResultSet rs)
    {
        try
        {
            if(rs!= null)
            {
                rs.close();
            }
            if(st!=null)
            {
                st.close();
            }
            if(ps!=null)
            {
                ps.close();
            }
            if(con!=null)
            {
                con.close();                
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}
