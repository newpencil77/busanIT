package magic.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ActionInterface
{
    public String executeCommand(HttpServletRequest request, HttpServletResponse response);
}
