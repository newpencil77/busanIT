package magic.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.member.MemberBean;
import magic.member.MemberDBBean;

public class CheckIDAction implements ActionInterface
{
    
    @Override
    public String executeCommand(HttpServletRequest request,
            HttpServletResponse response)
    {
        MemberDBBean dao = MemberDBBean.getInstance();
        
       int result=  dao.confirmID(request.getParameter("userid"));
       
       request.setAttribute("result", result);
       
//        return "/magicWebApp/member/checkID.jsp";
       return "callback";
    }
    
}
