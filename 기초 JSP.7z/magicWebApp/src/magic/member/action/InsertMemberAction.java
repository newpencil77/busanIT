package magic.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.member.MemberBean;
import magic.member.MemberDBBean;

public class InsertMemberAction implements ActionInterface
{
    
    @Override
    public String executeCommand(HttpServletRequest request,
            HttpServletResponse response)
    {
        MemberBean member= new MemberBean();
        
        member.setUserid(request.getParameter("userid"));
        member.setName(request.getParameter("name"));
        member.setPassword(request.getParameter("password"));
        member.setEmail(request.getParameter("email"));
        member.setAddress(request.getParameter("address"));
        
        MemberDBBean dao = MemberDBBean.getInstance();
        int result = dao.insertMember(member);
//        Integer result = dao.insertMember(member);
        
        
//        EL ǥ����� ����Ұ� �ƴϸ� request.getAttribute�� ���� �����;��ϴ� ��
//        EL���� result�� �ٷ� �� �� ����
        request.setAttribute("result", result);

//        return "redirect:/magicWebApp/member/login.jsp";
        return "/member/registerServlet.jsp";
        
    }
    
}
