package magic.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.member.MemberBean;
import magic.member.MemberDBBean;

public class LoginAction implements ActionInterface
{
    
    @Override
    public String executeCommand(HttpServletRequest request,
            HttpServletResponse response)
    {
        String id= request.getParameter("userid");
        String pwd= request.getParameter("password");
        
        MemberDBBean dao = MemberDBBean.getInstance();
        
        int result = dao.userLogin(id, pwd);
        
        request.setAttribute("result", result);

        if(result==1)
        {
          MemberBean member= dao.getMember(id);
          request.setAttribute("member", member);
        }
        
        return "/member/loginServlet.jsp";
    }
    
}
