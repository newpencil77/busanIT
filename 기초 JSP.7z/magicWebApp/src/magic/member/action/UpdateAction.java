package magic.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.member.MemberBean;
import magic.member.MemberDBBean;

public class UpdateAction implements ActionInterface
{

    @Override
    public String executeCommand(HttpServletRequest request,
            HttpServletResponse response)
    {
        MemberBean mb= new MemberBean();
        mb.setUserid(request.getParameter("userid"));
        mb.setName(request.getParameter("name"));
        mb.setPassword(request.getParameter("password"));
        mb.setAddress(request.getParameter("address"));
        mb.setEmail(request.getParameter("email"));
        
        MemberDBBean dao = MemberDBBean.getInstance();
        
        int result = dao.updateMember(mb);
        
        request.setAttribute("result", result);
        
        
        return "/member/updateServlet.jsp";
    }
    
}
