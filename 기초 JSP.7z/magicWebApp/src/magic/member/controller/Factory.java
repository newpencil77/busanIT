package magic.member.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import magic.member.action.ActionInterface;
import magic.member.action.CheckIDAction;
import magic.member.action.InsertMemberAction;
import magic.member.action.LoginAction;
import magic.member.action.UpdateAction;

public class Factory
{
    private static Factory instance = new Factory();
    
    public static Factory getInstance() 
    {
            return instance;
    }
    
    Map<String, ActionInterface> map = new HashMap<String, ActionInterface>();

    private Factory()
    {   
//        insert
        map.put("/member/insert.mem", new InsertMemberAction());
        
//        ���̵� üũ
        map.put("/member/checkID.mem", new CheckIDAction());
        
//      �α���
        map.put("/member/login.mem", new LoginAction());
        
//        ������Ʈ
        map.put("/member/update.mem", new UpdateAction());
        
    };
    
    
    public ActionInterface getAction(String cmd)
    {
        ActionInterface action = null;
        action= map.get(cmd);
        
        return action;
    }
    
    
}
