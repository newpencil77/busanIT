

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myUtil.HanConv;

@WebServlet("/multiPara")
public class MultiPara extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setContentType("text/html; charset=euc-kr");
	    PrintWriter out =response.getWriter();
	    
	    String [] item;
	    
	    item= request.getParameterValues("item");
	    out.println("���õ� �׸�");
	    
	    try
            {
                for(int i=0; i<item.length; i++)
                {
                    out.println(" : " + HanConv.toKor(item[i]));
                }
                out.println("�Դϴ�.");
                
            }
            catch (Exception e)
            {
                out.println("�� �����ϴ�.");
            }
	    
		
	}

}
