package test;

public class StringBuilderTest
{
    
    public static void main(String[] args)
    {
        StringBuilder sb = new StringBuilder(30);
        
        String [] st = {"������", "�󸶹�", "�����"};
        
        sb.append("������");
        sb.append("�󸶹�");
        sb.append("�����");
        
        System.out.println(sb);
        
        System.out.println(sb.indexOf(st[1]));
        System.out.println(sb.indexOf(st[1])+st[1].length());
        
//        sb.delete(sb.indexOf(st[0]), sb.indexOf(st[0])+st[0].length());
        sb.delete(sb.indexOf(st[1]), 
                  sb.indexOf(st[1])+st[1].length());

        
        System.out.println(sb);
    }
    
}
